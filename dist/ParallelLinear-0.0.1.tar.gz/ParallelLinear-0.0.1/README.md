This is a linear maths library that utilizes pyopencl to send calculations to the GPU. 
It is intended to be used as an underlying library for ML libraries, or graphics engine libraries
